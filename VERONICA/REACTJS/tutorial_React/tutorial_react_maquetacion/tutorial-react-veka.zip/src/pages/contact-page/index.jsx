import { Switch, Route, Link, useRouteMatch } from "react-router-dom";

import ContactEmail from "./contact_Email/contactEmail";
import ContactTel from "./contact_Tel/contactTel";

function ContactPage() {
  // let match = useRouteMatch();
  return (
    <div>
      <Link to={`/contactTel`}>Aquí puedes obtener teléfono</Link>
      <Link to={`/contactEmail`}>Aquí puedes obtener Email</Link>

      <Switch>
        <Route path={`/contact_Tel`}>
          <ContactTel />
        </Route>
        <Route path={`/contact_Email`}>
          <ContactEmail />
        </Route>
      </Switch>
    </div>
  );
}

export default ContactPage;
