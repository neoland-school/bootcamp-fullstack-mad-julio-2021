


function ContactEmail(){
    
        return (
            <div>
               
                 <h3>Mi Email:</h3>
                 <a href="mailto:hola@gmail.com">hola@gmail.com</a>
            </div>
        );
    
}

export default ContactEmail;