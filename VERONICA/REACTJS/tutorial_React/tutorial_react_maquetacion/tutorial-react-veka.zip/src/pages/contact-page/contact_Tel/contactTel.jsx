



function ContactTel(){
    
        return (
            <div>
                 <h3>Mis teléfonos:</h3>
                 <a href="tel:+3452982358">+3452982358</a>
                 <a href="tel:+3452982334">+3452982334</a>
                 </div>
        );
    
}

export default ContactTel;